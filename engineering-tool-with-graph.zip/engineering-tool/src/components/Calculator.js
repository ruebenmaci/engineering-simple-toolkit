import React, { useState } from 'react';
import { calculateFlowRate } from '../utils/engineeringFormulas';

function Calculator() {
  const [diameter, setDiameter] = useState('');
  const [velocity, setVelocity] = useState('');
  const [flowRate, setFlowRate] = useState(null);

  const handleCalculate = () => {
    const result = calculateFlowRate(diameter, velocity);
    setFlowRate(result);
  };

  return (
    <div className="box">
      <h2>Flow Rate Calculator</h2>
      <input
        type="number"
        placeholder="Diameter (m)"
        value={diameter}
        onChange={e => setDiameter(e.target.value)}
      />
      <input
        type="number"
        placeholder="Velocity (m/s)"
        value={velocity}
        onChange={e => setVelocity(e.target.value)}
      />
      <button onClick={handleCalculate}>Calculate</button>
      {flowRate && <p>Flow Rate: {flowRate} m³/s</p>}
    </div>
  );
}

export default Calculator;
