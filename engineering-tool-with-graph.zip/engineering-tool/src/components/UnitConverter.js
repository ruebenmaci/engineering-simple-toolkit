import React, { useState } from 'react';
import { convertUnits } from '../utils/unitConversions';

function UnitConverter() {
  const [inputValue, setInputValue] = useState('');
  const [convertedValue, setConvertedValue] = useState('');

  const handleConvert = () => {
    const result = convertUnits(inputValue, 'psi', 'kPa');
    setConvertedValue(result);
  };

  return (
    <div className="box">
      <h2>Unit Converter</h2>
      <input
        type="number"
        value={inputValue}
        onChange={e => setInputValue(e.target.value)}
        placeholder="Enter value in psi"
      />
      <button onClick={handleConvert}>Convert to kPa</button>
      {convertedValue && <p>Result: {convertedValue} kPa</p>}
    </div>
  );
}

export default UnitConverter;
