import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { Chart, LineElement, CategoryScale, LinearScale, PointElement } from 'chart.js';

Chart.register(LineElement, CategoryScale, LinearScale, PointElement);

const PressureDropGraph = () => {
  const [diameter, setDiameter] = useState(0.1); // in meters
  const [length, setLength] = useState(10); // in meters
  const [density, setDensity] = useState(1000); // kg/m³
  const [frictionFactor, setFrictionFactor] = useState(0.02); // constant

  const flowRates = Array.from({ length: 20 }, (_, i) => (i + 1) * 0.1); // m/s

  const pressureDrops = flowRates.map(v => {
    const deltaP = frictionFactor * (length / diameter) * (density * v * v / 2);
    return deltaP.toFixed(2);
  });

  const chartData = {
    labels: flowRates.map(v => `${v.toFixed(1)} m/s`),
    datasets: [
      {
        label: 'Pressure Drop (Pa)',
        data: pressureDrops,
        borderColor: 'rgba(75,192,192,1)',
        tension: 0.2,
      },
    ],
  };

  return (
    <div className="box">
      <h2>Pressure Drop vs Flow Rate</h2>
      <div>
        <label>Diameter (m): <input type="number" value={diameter} onChange={e => setDiameter(parseFloat(e.target.value))} /></label>
        <label>Length (m): <input type="number" value={length} onChange={e => setLength(parseFloat(e.target.value))} /></label>
        <label>Density (kg/m³): <input type="number" value={density} onChange={e => setDensity(parseFloat(e.target.value))} /></label>
      </div>
      <Line data={chartData} />
    </div>
  );
};

export default PressureDropGraph;
