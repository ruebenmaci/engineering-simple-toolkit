import React from 'react';
import UnitConverter from './components/UnitConverter';
import Calculator from './components/Calculator';
import PressureDropGraph from './components/PressureDropGraph';
import './styles.css';

function App() {
  return (
    <div className="app-container">
      <h1>Engineering Toolkit</h1>
      <UnitConverter />
      <Calculator />
      <PressureDropGraph />
    </div>
  );
}

export default App;
